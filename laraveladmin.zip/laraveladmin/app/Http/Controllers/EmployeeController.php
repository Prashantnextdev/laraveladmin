<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    public function index()
    {
        $employees = Employee::whereNull('parent_id')->get();
        $employeeTree = $this->buildTree($employees);
      
        return view('employees.index', compact('employeeTree'));
    }

    private function buildTree($employees)
    {
        $tree = [];

        foreach ($employees as $employee) {
            $node = $employee->toArray();
            $node['children'] = $this->buildTree($employee->children);

            $tree[] = $node;
        }

        return $tree;
    }
}
